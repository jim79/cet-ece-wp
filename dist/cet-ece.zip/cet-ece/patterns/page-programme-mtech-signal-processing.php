<?php
/**
 * Title: Programme page: M.Tech Signal Processing
 * Slug: cet-ece/page-programme-mtech-signal-processing
 * Categories: cet-ece-pages
 * Description: Starter content for this programme page, used when the theme creates the site’s pages.
 * Post Types: page
 * Inserter: false
 */
?>
<!-- wp:group {"layout":{"type":"grid","minimumColumnWidth":"170px","columnCount":4},"style":{"spacing":{"blockGap":"16px"}},"align":"wide"} -->
<div class="wp-block-group alignwide"><!-- wp:group {"className":"ece-card","style":{"spacing":{"padding":{"top":"14px","right":"18px","bottom":"14px","left":"18px"},"blockGap":"2px"}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group ece-card" style="padding-top:14px;padding-right:18px;padding-bottom:14px;padding-left:18px"><!-- wp:paragraph {"textColor":"muted","fontSize":"small","style":{"typography":{"fontWeight":"600"}}} -->
<p class="has-muted-color has-text-color has-small-font-size" style="font-weight:600">Intake</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"17px","fontWeight":"600"}}} -->
<p style="font-size:17px;font-weight:600">18</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"ece-card","style":{"spacing":{"padding":{"top":"14px","right":"18px","bottom":"14px","left":"18px"},"blockGap":"2px"}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group ece-card" style="padding-top:14px;padding-right:18px;padding-bottom:14px;padding-left:18px"><!-- wp:paragraph {"textColor":"muted","fontSize":"small","style":{"typography":{"fontWeight":"600"}}} -->
<p class="has-muted-color has-text-color has-small-font-size" style="font-weight:600">Duration</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"17px","fontWeight":"600"}}} -->
<p style="font-size:17px;font-weight:600">2 years, 4 semesters</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"ece-card","style":{"spacing":{"padding":{"top":"14px","right":"18px","bottom":"14px","left":"18px"},"blockGap":"2px"}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group ece-card" style="padding-top:14px;padding-right:18px;padding-bottom:14px;padding-left:18px"><!-- wp:paragraph {"textColor":"muted","fontSize":"small","style":{"typography":{"fontWeight":"600"}}} -->
<p class="has-muted-color has-text-color has-small-font-size" style="font-weight:600">Accreditation</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"17px","fontWeight":"600"}}} -->
<p style="font-size:17px;font-weight:600">NBA accredited for 2024–25 to 2026–27, to 30 June 2027</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group -->

<!-- wp:group {"className":"ece-card","style":{"spacing":{"padding":{"top":"14px","right":"18px","bottom":"14px","left":"18px"},"blockGap":"2px"}},"layout":{"type":"flex","orientation":"vertical"}} -->
<div class="wp-block-group ece-card" style="padding-top:14px;padding-right:18px;padding-bottom:14px;padding-left:18px"><!-- wp:paragraph {"textColor":"muted","fontSize":"small","style":{"typography":{"fontWeight":"600"}}} -->
<p class="has-muted-color has-text-color has-small-font-size" style="font-weight:600">Programme coordinator</p>
<!-- /wp:paragraph -->

<!-- wp:paragraph {"style":{"typography":{"fontSize":"17px","fontWeight":"600"}}} -->
<p style="font-size:17px;font-weight:600">[Faculty name]</p>
<!-- /wp:paragraph --></div>
<!-- /wp:group --></div>
<!-- /wp:group -->

<!-- wp:paragraph {"fontSize":"small"} -->
<p class="has-small-font-size">On this page: <a href="#overview">Overview</a> · <a href="#curriculum">Curriculum</a> · <a href="#outcomes">Outcomes</a> · <a href="#labs">Labs</a> · <a href="#contacts">Contacts</a></p>
<!-- /wp:paragraph -->

<!-- wp:heading {"anchor":"overview"} -->
<h2 id="overview" class="wp-block-heading">Overview</h2>
<!-- /wp:heading -->

<!-- wp:paragraph -->
<p>Started in 2005. [One paragraph: what the programme covers, electives, project work and internships, and what graduates go on to do.]</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"anchor":"curriculum"} -->
<h2 id="curriculum" class="wp-block-heading">Curriculum</h2>
<!-- /wp:heading -->

<!-- wp:table {"hasFixedLayout":false} -->
<figure class="wp-block-table"><table><thead><tr><th>Scheme</th><th>Applies to</th><th>Documents</th><th>Status</th></tr></thead><tbody><tr><td>2022 scheme</td><td>Admitted 2022 onwards</td><td><a href="#">Scheme and syllabus (PDF)</a></td><td>Current</td></tr><tr><td>2015 scheme</td><td>Admitted 2015–2021</td><td><a href="#">Scheme and syllabus (PDF)</a></td><td>Archived</td></tr></tbody></table></figure>
<!-- /wp:table -->

<!-- wp:paragraph {"textColor":"muted","fontSize":"small"} -->
<p class="has-muted-color has-text-color has-small-font-size">Regulations and the academic calendar come from APJ Abdul Kalam Technological University: <a href="https://ktu.edu.in/">ktu.edu.in</a>.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"anchor":"outcomes"} -->
<h2 id="outcomes" class="wp-block-heading">Outcomes</h2>
<!-- /wp:heading -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Programme educational objectives (PEOs)</h3>
<!-- /wp:heading -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li><strong>PEO1:</strong> Demonstrate the ability to cater to the diverse and evolving needs of the industry, through sustainable and eco-friendly solutions.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><strong>PEO2:</strong> Formulate novel solutions to existing and emerging problems in the domain of signal processing through research.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><strong>PEO3:</strong> Exhibit leadership skills, professional competence and entrepreneurial skills.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><strong>PEO4:</strong> Uphold professional and ethical values.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:heading {"level":3} -->
<h3 class="wp-block-heading">Programme outcomes (POs)</h3>
<!-- /wp:heading -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li><strong>PO1:</strong> An ability to independently carry out research/investigation and development work to solve practical problems.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><strong>PO2:</strong> An ability to write and present a substantial technical report/document.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><strong>PO3:</strong> Students should be able to demonstrate a degree of mastery over the area as per the specialization of the program. The mastery should be at a level higher than the requirements in the appropriate bachelor program.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><strong>PO4:</strong> Students will be able to demonstrate ethics related to intellectual properties and professional practice.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><strong>PO5:</strong> Ability to learn independently based on the individual and system level needs especially in the context of rapidly changing technology.</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li><strong>PO6:</strong> Design and develop algorithms for computer aided signal processing and implement state-of-the-art signal processing systems.</li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->

<!-- wp:paragraph -->
<p>Attainment reports are on the <a href="/academics/obe/">outcome-based education</a> page.</p>
<!-- /wp:paragraph -->

<!-- wp:heading {"anchor":"labs"} -->
<h2 id="labs" class="wp-block-heading">Labs used in this programme</h2>
<!-- /wp:heading -->

<!-- wp:cet-ece/lab-list {"type":"teaching","programme":"mtech"} /-->

<!-- wp:heading {"anchor":"contacts"} -->
<h2 id="contacts" class="wp-block-heading">Contacts</h2>
<!-- /wp:heading -->

<!-- wp:list -->
<ul class="wp-block-list"><!-- wp:list-item -->
<li>Programme coordinator: [Faculty name], [name]@cet.ac.in</li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Staff advisors: <a href="/staff-advisors/">current batches</a></li>
<!-- /wp:list-item -->

<!-- wp:list-item -->
<li>Admissions: GATE score and the state PG admission process [confirm], see <a href="/contact/">contact</a></li>
<!-- /wp:list-item --></ul>
<!-- /wp:list -->
